const modal = document.querySelector(".modal");
const overlay = document.querySelector(".overlay");
const openModalBtn = document.querySelector(".btn-open");
const closeModalBtn = document.querySelector(".btn-close");

// close modal function
const closeModal = function () {
  modal.classList.add("hidden");
  overlay.classList.add("hidden");
};

// close the modal when the close button and overlay is clicked
closeModalBtn.addEventListener("click", closeModal);
overlay.addEventListener("click", closeModal);

// close modal when the Esc key is pressed
document.addEventListener("keydown", function (e) {
  if (e.key === "Escape" && !modal.classList.contains("hidden")) {
    closeModal();
  }
});

// open modal function
const openModal = function () {
  modal.classList.remove("hidden");
  overlay.classList.remove("hidden");
};
// open modal event
openModalBtn.addEventListener("click", openModal);


//artista
async function insertcadastro(event) {
  event.preventDefault()
  const formData = new FormData(event.target)
  const response = await fetch('backend/insertartista.php', {
      method: 'POST',
      body: formData
  })
  const result = await response.json()
  if (result?.success) {
      alert('Seu Filme ' + result.data.name + ' foi cadastrado com sucesso!')
      loadProductions()
  }

}

async function loadProductions() {
  const response = await fetch('backend/listartista.php')
  const result = await response.json()
  if (result?.success) {

      const listProductions = document.querySelector('.content_Cardsartist')

      const filmes = result.data
      console.log(filmes)
      filmes.map((film) => {
          listProductions.innerHTML +=
              `
              <a href="#"><div class="cardartista_exemplemaior"><div class="cardartista_menor">
              <div class="contentimgartista"><img src="${film.coverartista}" alt=""></div><div class="textcardartista"><p class="linkartista">${film.name}</p><div class="textcardmenorartista"><p>Artista</p></div></div>
  
              </div>
              </div>
          </a>
         `

      })
  } else {
      alert('Erro ao carregar')
  }

}

async function deleteProduction(id){
  const response = await fetch('backend/delete.php?id='+id)
  const result = await response.json()
  if(result?.success){
      alert('Seu filme foi deletado com sucesso!')
      loadProductions()
  }
  
}

async function loadProductionData(id){
  const response = await fetch('backend/get-production-by-id-.php?id=' +id)
  const result = await response.json()
  if(result?.success){
      showModal('#modal-editar')
      const title = document.querySelector
      ('#modal-editar input[name=title]')
      title.value = result.data.titulo
      const description = document.querySelector
      ('#modal-editar input[name=description]')
      title.value = result.data.titulo
  }
}