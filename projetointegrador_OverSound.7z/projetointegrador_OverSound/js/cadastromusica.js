const modalmusica = document.querySelector(".modalmusica");
const overlaymusica = document.querySelector(".overlaymusica");
const openModalBtn2 = document.querySelector(".openModalBtn2");
const closeModalBtn2 = document.querySelector(".closeModalBtn2");

// close modal function
const closeModal2 = function () {
  modalmusica.classList.add("hidden2");
  overlaymusica.classList.add("hidden2");
};

// close the modal when the close button and overlay is clicked
closeModalBtn2.addEventListener("click", closeModal2);
overlaymusica.addEventListener("click", closeModal2);

// close modal when the Esc key is pressed
document.addEventListener("keydown", function (e) {
  if (e.key === "Escape" && !modalmusica.classList.contains("hidden2")) {
    closeModal2();
  }
});

// open modal function
const openModalmusica = function () {
  modalmusica.classList.remove("hidden2");
  overlaymusica.classList.remove("hidden2");
};
// open modal event
openModalBtn2.addEventListener("click", openModalmusica);