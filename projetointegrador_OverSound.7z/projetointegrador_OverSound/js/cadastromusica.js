const modalmusica = document.querySelector(".modalmusica");
const overlaymusica = document.querySelector(".overlaymusica");
const openModalBtn2 = document.querySelector(".openModalBtn2");
const closeModalBtn2 = document.querySelector(".closeModalBtn2");

// close modal function
const closeModal2 = function () {
  modalmusica.classList.add("hidden2");
  overlaymusica.classList.add("hidden2");
};

// close the modal when the close button and overlay is clicked
closeModalBtn2.addEventListener("click", closeModal2);
overlaymusica.addEventListener("click", closeModal2);

// close modal when the Esc key is pressed
document.addEventListener("keydown", function (e) {
  if (e.key === "Escape" && !modalmusica.classList.contains("hidden2")) {
    closeModal2();
  }
});

// open modal function
const openModalmusica = function () {
  modalmusica.classList.remove("hidden2");
  overlaymusica.classList.remove("hidden2");
};
// open modal event
openModalBtn2.addEventListener("click", openModalmusica);

async function insert(event) {
  event.preventDefault()
  const formData = new FormData(event.target)
  const response = await fetch('backend/insert.php', {
      method: 'POST',
      body: formData
  })
  const result = await response.json()
  if (result?.success) {
      alert('Seu Filme ' + result.data.namemusic + ' foi cadastrado com sucesso!')
      loadProductions()
  }

}

async function loadProductions() {
  const response = await fetch('backend/list.php')
  const result = await response.json()
  if (result?.success) {

      const listProductions = document.querySelector('.content_Cards')

      const filmes = result.data
      console.log(filmes)
      filmes.map((film) => {
          listProductions.innerHTML +=
              `
              <a href="#"><div class="card1_exemplemaior"><div class="card1_menor">
                  <div class="contentimg"><img src="${film.cover}" alt=""></div><div class="textcard"><p class="linkplaylist">${film.namemusic}</p><div class="textcardmenor"><p>${film.description}</p></div></div>
      
                  </div>
                  </div>
              </a>
         `

      })
  } else {
      alert('Erro ao carregar')
  }

}

async function deleteProduction(id){
  const response = await fetch('backend/delete.php?id='+id)
  const result = await response.json()
  if(result?.success){
      alert('Seu filme foi deletado com sucesso!')
      loadProductions()
  }
  
}

async function loadProductionData(id){
  const response = await fetch('backend/get-production-by-id-.php?id=' +id)
  const result = await response.json()
  if(result?.success){
      showModal('#modal-editar')
      const title = document.querySelector
      ('#modal-editar input[name=title]')
      title.value = result.data.titulo
      const description = document.querySelector
      ('#modal-editar input[name=description]')
      title.value = result.data.titulo
  }
}