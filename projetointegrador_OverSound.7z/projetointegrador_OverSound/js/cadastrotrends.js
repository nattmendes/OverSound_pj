const modaltrends = document.querySelector(".modaltrends");
const overlaytrends  = document.querySelector(".overlaytrends");
const openModalBtntrends  = document.querySelector(".openModalBtntrends");
const closeModalBtntrends  = document.querySelector(".closeModalBtntrends");

// close modal function
const closeModal3 = function () {
  modaltrends.classList.add("hiddentrends");
  overlaytrends.classList.add("hiddentrends");
};

// close the modal when the close button and overlay is clicked
closeModalBtntrends.addEventListener("click", closeModal3);
overlaytrends.addEventListener("click", closeModal3);

// close modal when the Esc key is pressed
document.addEventListener("keydown", function (e) {
  if (e.key === "Escape" && !modaltrends.classList.contains("hiddentrends")) {
    closeModal3();
  }
});

// open modal function
const openModal3 = function () {
  modaltrends.classList.remove("hiddentrends");
  overlaytrends.classList.remove("hiddentrends");
};
// open modal event

async function insertTrends(event) {
  event.preventDefault()
  const formData = new FormData(event.target)
  const response = await fetch('backend/inserttrends.php', {
      method: 'POST',
      body: formData
  })
  const result = await response.json()
  if (result?.success) {
      alert('Seu Filme ' + result.data.tittle + ' foi cadastrado com sucesso!')
      loadTrends()
  }

}

async function loadTrends() {
  const response = await fetch('backend/listtrends.php')
  const result = await response.json()
  if (result?.success) {

      const listProductions = document.querySelector('.contenti')

      const filmes = result.data
      console.log(filmes)
      filmes.map((film) => {
          listProductions.innerHTML +=
              `
              <a href="#">
              <div class="noticia">
              <p class="colortextnoticia">${film.tittle}</p>
              <p class="subcolortextnoticia">${film.text}</p></div></a>
         `

      })
  } else {
      alert('Erro ao carregar')
  }

}