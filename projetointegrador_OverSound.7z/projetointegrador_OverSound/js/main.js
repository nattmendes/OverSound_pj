function showModal(idModal) {
    const modal = document.querySelector(idModal);
    modal.style.display = 'flex'
}

function hideModal(idModal, event) {
    if (event.target.className === 'modal') {
        const modal = document.querySelector(idModal)
        modal.style.display = 'none'
    }
}


function closeAllModal() {

    const modais = document.querySelectorAll('.modal')
    modais.forEach(modal => {
        modal.style.display = 'none'
    })


}

async function insert(event) {
    event.preventDefault()
    const formData = new FormData(event.target)
    const response = await fetch('backend/insert.php', {
        method: 'POST',
        body: formData
    })
    const result = await response.json()
    if (result?.success) {
        closeAllModal()
        alert('Seu Filme ' + result.data.title + ' foi cadastrado com sucesso!')
        loadProductions()
    }

}

async function loadProductions() {
    const response = await fetch('backend/list.php')
    const result = await response.json()
    if (result?.success) {

        const listProductions = document.querySelector('#productions')

        const filmes = result.data
        console.log(filmes)
        filmes.map((film) => {
            listProductions.innerHTML +=
                `
           <div class="card-movie">
                    <a href="filme">
                        <div class="mask"></div>
                         <img src="${film.capa}" alt="${film.titulo}">
                    </a>
                        <div>
                    <a href="filme">
                        <h2>${film.titulo}</h2>
                    </a>
                    <div>
                    
                        <p>${film.categoria}</p>
                        <img src="img/trash-icon.svg" alt="Apagar" onclick="deleteProduction(${film.id})"/>
                        <img src="img/edit-icon.svg" alt="Apagar" onclick="edit({${JSON.stringify(film)}})"/>
                    </div>
              </div>
            </div>
           `

        })
    } else {
        alert('Erro ao carregar')
    }

}

async function deleteProduction(id){
    const response = await fetch('backend/delete.php?id='+id)
    const result = await response.json()
    if(result?.success){
        alert('Seu filme foi deletado com sucesso!')
        loadProductions()
    }
    
}

async function loadProductionData(id){
    const response = await fetch('backend/get-production-by-id-.php?id=' +id)
    const result = await response.json()
    if(result?.success){
        showModal('#modal-editar')
        const title = document.querySelector
        ('#modal-editar input[name=title]')
        title.value = result.data.titulo
        const description = document.querySelector
        ('#modal-editar input[name=description]')
        title.value = result.data.titulo
    }
}