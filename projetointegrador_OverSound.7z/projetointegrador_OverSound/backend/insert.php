<?php
require('database.php');

  $namemusic = $_POST["namemusic"];
  $description = $_POST["description"];
  $text = $_POST["text"];
  $cover = $_POST["cover"];

  try{

  $stmt = $conn->prepare("INSERT INTO cadastromusica (namemusic, description, text, cover)
  VALUES (:namemusic, :description, :text, :cover)");
  $stmt->bindParam(':namemusic', $namemusic);
  $stmt->bindParam(':description', $description);
  $stmt->bindParam(':text', $text);
  $stmt->bindParam(':cover', $cover);

  $stmt->execute();
  $id = $conn->lastInsertId();

  $result["success"]["message"] = "Cadastro com sucesso!";

  $result["data"]["id"] = $id;
  $result["data"]["namemusic"] = $namemusic;
  $result["data"]["description"] = $description;
  $result["data"]["text"] = $text;
  $result["data"]["cover"] = $cover;

  header('Content-Type: text/json');
  echo json_encode($result);

} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>