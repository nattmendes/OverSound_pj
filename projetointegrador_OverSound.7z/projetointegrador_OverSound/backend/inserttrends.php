<?php
require('database.php');

  $tittle = $_POST["tittle"];
  $text = $_POST["text"];

  try{

  $stmt = $conn->prepare("INSERT INTO cadastrotrends (tittle, text)
  VALUES (:tittle, :text)");
  $stmt->bindParam(':tittle', $tittle);
  $stmt->bindParam(':text', $text);

  $stmt->execute();
  $id = $conn->lastInsertId();

  $result["success"]["message"] = "Cadastro com sucesso!";

  $result["data"]["id"] = $id;
  $result["data"]["tittle"] = $tittle;
  $result["data"]["text"] = $text;

  header('Content-Type: text/json');
  echo json_encode($result);

} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>