<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "oversound";

try{
    $conn = new PDO("mysql:host=$servername;dbname=$database",
    $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   /* echo "Banco Conectado!";*/
} catch(PDOException $e) {
    echo "connection failed: " . $e->getMessage();
}
?>
