<?php
require('database.php');

  try{

  $stmt = $conn->prepare("SELECT id, name, coverartista, text FROM cadastroartista;");
  $stmt->execute();

  $producoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
  $result["success"]["message"] = "Mucica listada com sucesso";
  $result["data"] = $producoes;

  header('Content-Type: text/json');
  echo json_encode($result);

} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>