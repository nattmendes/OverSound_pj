<?php
require('database.php');

  $name = $_POST["name"];
  $coverartista = $_POST["coverartista"];

  try{

  $stmt = $conn->prepare("INSERT INTO cadastroartista (name, cover)
  VALUES (:name, :coverartista)");
  $stmt->bindParam(':name', $name);
  $stmt->bindParam(':coverartista', $coverartista);

  $stmt->execute();
  $id = $conn->lastInsertId();

  $result["success"]["message"] = "Cadastro com sucesso!";

  $result["data"]["id"] = $id;
  $result["data"]["name"] = $name;
  $result["data"]["coverartista"] = $coverartista;

  header('Content-Type: text/json');
  echo json_encode($result);

} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>